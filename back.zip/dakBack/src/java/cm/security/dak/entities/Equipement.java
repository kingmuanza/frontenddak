/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cm.security.dak.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Muanza Kangudie
 */
@Entity
@Table(name = "equipement")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Equipement.findAll", query = "SELECT e FROM Equipement e"),
    @NamedQuery(name = "Equipement.findByIdequipement", query = "SELECT e FROM Equipement e WHERE e.idequipement = :idequipement"),
    @NamedQuery(name = "Equipement.findByDateAffection", query = "SELECT e FROM Equipement e WHERE e.dateAffection = :dateAffection"),
    @NamedQuery(name = "Equipement.findByPoste", query = "SELECT e FROM Equipement e WHERE e.poste = :poste"),
    @NamedQuery(name = "Equipement.findByMatricule", query = "SELECT e FROM Equipement e WHERE e.matricule = :matricule"),
    @NamedQuery(name = "Equipement.findByArret", query = "SELECT e FROM Equipement e WHERE e.arret = :arret"),
    @NamedQuery(name = "Equipement.findByQualite", query = "SELECT e FROM Equipement e WHERE e.qualite = :qualite"),
    @NamedQuery(name = "Equipement.findByHoraire", query = "SELECT e FROM Equipement e WHERE e.horaire = :horaire"),
    @NamedQuery(name = "Equipement.findByType", query = "SELECT e FROM Equipement e WHERE e.type = :type"),
    @NamedQuery(name = "Equipement.findByRemplacant", query = "SELECT e FROM Equipement e WHERE e.remplacant = :remplacant"),
    @NamedQuery(name = "Equipement.findByJour", query = "SELECT e FROM Equipement e WHERE e.jour = :jour"),
    @NamedQuery(name = "Equipement.findByPlacement", query = "SELECT e FROM Equipement e WHERE e.placement = :placement"),
    @NamedQuery(name = "Equipement.findByJourPl", query = "SELECT e FROM Equipement e WHERE e.jourPl = :jourPl")})
public class Equipement implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idequipement")
    private Integer idequipement;
    @Column(name = "date_affection")
    private Integer dateAffection;
    @Column(name = "poste")
    private Integer poste;
    @Size(max = 45)
    @Column(name = "matricule")
    private String matricule;
    @Column(name = "arret")
    @Temporal(TemporalType.DATE)
    private Date arret;
    @Size(max = 45)
    @Column(name = "qualite")
    private String qualite;
    @Size(max = 45)
    @Column(name = "horaire")
    private String horaire;
    @Size(max = 45)
    @Column(name = "type")
    private String type;
    @Size(max = 45)
    @Column(name = "remplacant")
    private String remplacant;
    @Size(max = 45)
    @Column(name = "jour")
    private String jour;
    @Size(max = 45)
    @Column(name = "placement")
    private String placement;
    @Size(max = 45)
    @Column(name = "jour_pl")
    private String jourPl;

    public Equipement() {
    }

    public Equipement(Integer idequipement) {
        this.idequipement = idequipement;
    }

    public Integer getIdequipement() {
        return idequipement;
    }

    public void setIdequipement(Integer idequipement) {
        this.idequipement = idequipement;
    }

    public Integer getDateAffection() {
        return dateAffection;
    }

    public void setDateAffection(Integer dateAffection) {
        this.dateAffection = dateAffection;
    }

    public Integer getPoste() {
        return poste;
    }

    public void setPoste(Integer poste) {
        this.poste = poste;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public Date getArret() {
        return arret;
    }

    public void setArret(Date arret) {
        this.arret = arret;
    }

    public String getQualite() {
        return qualite;
    }

    public void setQualite(String qualite) {
        this.qualite = qualite;
    }

    public String getHoraire() {
        return horaire;
    }

    public void setHoraire(String horaire) {
        this.horaire = horaire;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRemplacant() {
        return remplacant;
    }

    public void setRemplacant(String remplacant) {
        this.remplacant = remplacant;
    }

    public String getJour() {
        return jour;
    }

    public void setJour(String jour) {
        this.jour = jour;
    }

    public String getPlacement() {
        return placement;
    }

    public void setPlacement(String placement) {
        this.placement = placement;
    }

    public String getJourPl() {
        return jourPl;
    }

    public void setJourPl(String jourPl) {
        this.jourPl = jourPl;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idequipement != null ? idequipement.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Equipement)) {
            return false;
        }
        Equipement other = (Equipement) object;
        if ((this.idequipement == null && other.idequipement != null) || (this.idequipement != null && !this.idequipement.equals(other.idequipement))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.security.dak.entities.Equipement[ idequipement=" + idequipement + " ]";
    }
    
}
