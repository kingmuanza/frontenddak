/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cm.security.dak.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Muanza Kangudie
 */
@Entity
@Table(name = "equipement_vigile")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "EquipementVigile.findAll", query = "SELECT e FROM EquipementVigile e"),
    @NamedQuery(name = "EquipementVigile.findByIdequipementVigile", query = "SELECT e FROM EquipementVigile e WHERE e.idequipementVigile = :idequipementVigile"),
    @NamedQuery(name = "EquipementVigile.findByCasquette", query = "SELECT e FROM EquipementVigile e WHERE e.casquette = :casquette"),
    @NamedQuery(name = "EquipementVigile.findByChemisette", query = "SELECT e FROM EquipementVigile e WHERE e.chemisette = :chemisette"),
    @NamedQuery(name = "EquipementVigile.findBySifflet", query = "SELECT e FROM EquipementVigile e WHERE e.sifflet = :sifflet"),
    @NamedQuery(name = "EquipementVigile.findByPantalon", query = "SELECT e FROM EquipementVigile e WHERE e.pantalon = :pantalon"),
    @NamedQuery(name = "EquipementVigile.findByPorteMatraque", query = "SELECT e FROM EquipementVigile e WHERE e.porteMatraque = :porteMatraque"),
    @NamedQuery(name = "EquipementVigile.findByMatraque", query = "SELECT e FROM EquipementVigile e WHERE e.matraque = :matraque"),
    @NamedQuery(name = "EquipementVigile.findByCombinaison", query = "SELECT e FROM EquipementVigile e WHERE e.combinaison = :combinaison"),
    @NamedQuery(name = "EquipementVigile.findByVeste", query = "SELECT e FROM EquipementVigile e WHERE e.veste = :veste"),
    @NamedQuery(name = "EquipementVigile.findByPullover", query = "SELECT e FROM EquipementVigile e WHERE e.pullover = :pullover"),
    @NamedQuery(name = "EquipementVigile.findByManteau", query = "SELECT e FROM EquipementVigile e WHERE e.manteau = :manteau"),
    @NamedQuery(name = "EquipementVigile.findByEpaulettes", query = "SELECT e FROM EquipementVigile e WHERE e.epaulettes = :epaulettes")})
public class EquipementVigile implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idequipement_vigile")
    private Integer idequipementVigile;
    @Column(name = "casquette")
    private Integer casquette;
    @Column(name = "chemisette")
    private Integer chemisette;
    @Column(name = "sifflet")
    private Integer sifflet;
    @Column(name = "pantalon")
    private Integer pantalon;
    @Column(name = "porte_matraque")
    private Integer porteMatraque;
    @Column(name = "matraque")
    private Integer matraque;
    @Column(name = "combinaison")
    private Integer combinaison;
    @Column(name = "veste")
    private Integer veste;
    @Column(name = "pullover")
    private Integer pullover;
    @Column(name = "manteau")
    private Integer manteau;
    @Column(name = "epaulettes")
    private Integer epaulettes;
    @JoinColumn(name = "idvigile", referencedColumnName = "idvigile")
    @ManyToOne
    private Vigile idvigile;

    public EquipementVigile() {
    }

    public EquipementVigile(Integer idequipementVigile) {
        this.idequipementVigile = idequipementVigile;
    }

    public Integer getIdequipementVigile() {
        return idequipementVigile;
    }

    public void setIdequipementVigile(Integer idequipementVigile) {
        this.idequipementVigile = idequipementVigile;
    }

    public Integer getCasquette() {
        return casquette;
    }

    public void setCasquette(Integer casquette) {
        this.casquette = casquette;
    }

    public Integer getChemisette() {
        return chemisette;
    }

    public void setChemisette(Integer chemisette) {
        this.chemisette = chemisette;
    }

    public Integer getSifflet() {
        return sifflet;
    }

    public void setSifflet(Integer sifflet) {
        this.sifflet = sifflet;
    }

    public Integer getPantalon() {
        return pantalon;
    }

    public void setPantalon(Integer pantalon) {
        this.pantalon = pantalon;
    }

    public Integer getPorteMatraque() {
        return porteMatraque;
    }

    public void setPorteMatraque(Integer porteMatraque) {
        this.porteMatraque = porteMatraque;
    }

    public Integer getMatraque() {
        return matraque;
    }

    public void setMatraque(Integer matraque) {
        this.matraque = matraque;
    }

    public Integer getCombinaison() {
        return combinaison;
    }

    public void setCombinaison(Integer combinaison) {
        this.combinaison = combinaison;
    }

    public Integer getVeste() {
        return veste;
    }

    public void setVeste(Integer veste) {
        this.veste = veste;
    }

    public Integer getPullover() {
        return pullover;
    }

    public void setPullover(Integer pullover) {
        this.pullover = pullover;
    }

    public Integer getManteau() {
        return manteau;
    }

    public void setManteau(Integer manteau) {
        this.manteau = manteau;
    }

    public Integer getEpaulettes() {
        return epaulettes;
    }

    public void setEpaulettes(Integer epaulettes) {
        this.epaulettes = epaulettes;
    }

    public Vigile getIdvigile() {
        return idvigile;
    }

    public void setIdvigile(Vigile idvigile) {
        this.idvigile = idvigile;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idequipementVigile != null ? idequipementVigile.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EquipementVigile)) {
            return false;
        }
        EquipementVigile other = (EquipementVigile) object;
        if ((this.idequipementVigile == null && other.idequipementVigile != null) || (this.idequipementVigile != null && !this.idequipementVigile.equals(other.idequipementVigile))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.security.dak.entities.EquipementVigile[ idequipementVigile=" + idequipementVigile + " ]";
    }
    
}
