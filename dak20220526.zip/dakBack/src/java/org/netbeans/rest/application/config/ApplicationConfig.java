/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.rest.application.config;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author Muanza Kangudie
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(cm.security.dak.entities.service.service.AffectationFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.EquipementFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.EquipementVigileFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.MotifFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.NationaliteFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.PosteFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.QuartierFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.StatutFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.SuiviPosteFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.VigileFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.VilleFacadeREST.class);
        resources.add(cm.security.dak.entities.service.service.ZoneFacadeREST.class);
        resources.add(cm.security.dak.filters.CORSFilter.class);
        resources.add(cm.security.dak.filters.CORSFilterRequest.class);
    }
    
}
