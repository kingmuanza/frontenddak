/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cm.security.dak.entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Muanza Kangudie
 */
@Entity
@Table(name = "contrat_avenant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ContratAvenant.findAll", query = "SELECT c FROM ContratAvenant c"),
    @NamedQuery(name = "ContratAvenant.findByIdcontratAvenant", query = "SELECT c FROM ContratAvenant c WHERE c.idcontratAvenant = :idcontratAvenant"),
    @NamedQuery(name = "ContratAvenant.findByDate", query = "SELECT c FROM ContratAvenant c WHERE c.date = :date"),
    @NamedQuery(name = "ContratAvenant.findByDescription", query = "SELECT c FROM ContratAvenant c WHERE c.description = :description")})
public class ContratAvenant implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idcontrat_avenant")
    private Integer idcontratAvenant;
    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;
    @Size(max = 255)
    @Column(name = "description")
    private String description;
    @OneToMany(mappedBy = "versionContrat")
    private Collection<PosteVigile> posteVigileCollection;
    @JoinColumn(name = "idcontrat", referencedColumnName = "idcontrat")
    @ManyToOne
    private Contrat idcontrat;
    @OneToMany(mappedBy = "versionContrat")
    private Collection<PosteEquipement> posteEquipementCollection;

    public ContratAvenant() {
    }

    public ContratAvenant(Integer idcontratAvenant) {
        this.idcontratAvenant = idcontratAvenant;
    }

    public Integer getIdcontratAvenant() {
        return idcontratAvenant;
    }

    public void setIdcontratAvenant(Integer idcontratAvenant) {
        this.idcontratAvenant = idcontratAvenant;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Collection<PosteVigile> getPosteVigileCollection() {
        return posteVigileCollection;
    }

    public void setPosteVigileCollection(Collection<PosteVigile> posteVigileCollection) {
        this.posteVigileCollection = posteVigileCollection;
    }

    public Contrat getIdcontrat() {
        return idcontrat;
    }

    public void setIdcontrat(Contrat idcontrat) {
        this.idcontrat = idcontrat;
    }

    @XmlTransient
    public Collection<PosteEquipement> getPosteEquipementCollection() {
        return posteEquipementCollection;
    }

    public void setPosteEquipementCollection(Collection<PosteEquipement> posteEquipementCollection) {
        this.posteEquipementCollection = posteEquipementCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcontratAvenant != null ? idcontratAvenant.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ContratAvenant)) {
            return false;
        }
        ContratAvenant other = (ContratAvenant) object;
        if ((this.idcontratAvenant == null && other.idcontratAvenant != null) || (this.idcontratAvenant != null && !this.idcontratAvenant.equals(other.idcontratAvenant))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.security.dak.entities.ContratAvenant[ idcontratAvenant=" + idcontratAvenant + " ]";
    }
    
}
